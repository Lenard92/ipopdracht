package handlers

import (
	"html/template"
	"log"
	"net/http"
	"sort"
	"strconv"
	"time"

	"../repository"
	. "../types"
)

func OrderlaptopHandler(response http.ResponseWriter, request *http.Request) {
	log.Println("Posting order")

	if request.Method == "POST" {

		request.ParseForm()

		customer := Customer{
			Email:   request.FormValue("email"),
			Name:    request.FormValue("name"),
			Address: request.FormValue("address"),
			Phone:   request.FormValue("phone"),
		}

		// Save the customer to the JSON file
		repository.SaveCustomer(customer)

		timestamp := time.Now()

		order := Order{
			No:    getOrderNo(),
			Date:  timestamp,
			Email: customer.Email,
		}

		laptops := request.Form["laptop"]
		quantities := request.Form["quantity"]

		for i := 0; i < len(laptops); i++ {
			if laptops[i] != "" && quantities[i] != "" {
				laptopno, _ := strconv.Atoi(laptops[i])
				quantity, _ := strconv.Atoi(quantities[i])

				orderline := OrderLine{
					LaptopNo: laptopno,
					Quantity: quantity,
				}

				order.OrderLines = append(order.OrderLines, orderline)
			}
		}

		order.Total = calculateTotal(order)

		// Save the order to the JSON file
		repository.SaveOrder(order)

		log.Printf("Placing order %v for customer: %v\n ", order, customer)

		render, _ := template.ParseFiles("templates/orderlaptopsuccess.html")
		render.Execute(response, nil)
		return
	}

	laptops, _ := repository.LoadLaptops()

	data := struct {
		Rows    []bool
		Laptops []Laptop
	}{
		[]bool{true, true, true, true},
		laptops,
	}

	render, err := template.ParseFiles("templates/orderlaptop.html")

	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "../html/error.html", http.StatusBadRequest)
	}

	render.Execute(response, data)
}

func getOrderNo() int {
	orders, _ := repository.LoadOrders()
	if len(orders) == 0 {
		return 1
	}
	sort.Slice(orders, func(x, y int) bool {
		return orders[x].No < orders[y].No
	})
	return orders[len(orders)-1].No + 1
}

func calculateTotal(order Order) float32 {
	var total float32
	laptops, err := repository.LoadLaptops()       // laad de laptops //
	for _, laptoporder := range order.OrderLines { // Ranged over json file orders //
		if err != nil { // return -1 is afkappen //
			return -1
		}

		for _, laptop := range laptops {
			if laptoporder.LaptopNo == laptop.No {
				total += (laptop.Price * (float32)(laptoporder.Quantity)) // berekent de prijs, laptop prijs x quantity //
			}
		}
	}
	return total
}
