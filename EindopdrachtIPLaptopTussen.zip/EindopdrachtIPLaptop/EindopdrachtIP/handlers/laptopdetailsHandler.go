package handlers

import (
	"html/template"
	"log"
	"net/http"
	"strconv"

	"../repository"
	"../types"
)

type Laptopdetail struct {
	Review []types.Review
	Laptop types.Laptop
}

func LaptopdetailsHandler(response http.ResponseWriter, request *http.Request) {
	log.Println("Viewing laptop details")

	tmp := request.URL.Query()["no"]
	laptopno, err := strconv.Atoi(tmp[0])

	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "/html/error.html", http.StatusBadRequest)
		return
	}

	laptop, err := repository.LoadLaptops()
	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "/html/error.html", http.StatusInternalServerError)
		return
	}
	
	
	
	// beoordelingen, err := repository.LoadReviews()
	
	
	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "/html/error.html", http.StatusInternalServerError)
		return
	}	
	beoordeling,_:= repository.LoadReviewsForLaptop(laptopno)
	
	
	for _, laptop  := range laptop{
		
	
					
	render, _ := template.ParseFiles("templates/laptopdetails.html")
	Data:= Laptopdetail{
		Laptop: laptop,
		Review: beoordeling,
	}
	render.Execute(response, Data)
	return
	}

		

	
}
