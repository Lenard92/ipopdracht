package handlers

import (
	"html/template"
	"log"
	"net/http"

	"../repository"
)

// OrdersHandler parses the saved orders to orders.html
func OrdersHandler(response http.ResponseWriter, request *http.Request) {
	log.Println("Viewing orders")

	orders, err := repository.LoadOrders()
	// Handles the errors that might come up
	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "../html/error.html", http.StatusInternalServerError)
	}

	render, _ := template.ParseFiles("templates/orders.html")

	render.Execute(response, orders)
}
