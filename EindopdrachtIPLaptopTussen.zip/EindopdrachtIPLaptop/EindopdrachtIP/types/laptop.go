package types

type Laptop struct {
	No          int     `json:"no"`
	Brand       string  `json:"brand"`
	Name        string  `json:"name"`
	Type        string  `json:"type"`
	Price       float32 `json:"price"`
	Description string  `json:"description"`

	ScreenSize float32 `json:"screensize"`
	Processor  string  `json:"processor"`
	GPU        string  `json:"gpu"`
	RAMSize    int     `json:"ram"`
	HDSize     int     `json:"hd"`

	Cores       int     `json:"cores"`
	OS          string  `json:"os"`
	Gewicht     float32 `json:"kg"`
	Toetsenbord string  `json:"toetsenbord"`
}
