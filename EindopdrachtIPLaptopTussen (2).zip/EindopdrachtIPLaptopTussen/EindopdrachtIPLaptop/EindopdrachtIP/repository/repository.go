package repository

import (
	"errors"
	"log"

	. "../types"
)

const (
	CUSTOMERSFILE = "./data/customers.json"
	LAPTOPSFILE   = "./data/laptops.json"
	ORDERSFILE    = "./data/orders.json"
	REVIEWFILE    = "./data/review.json"
)

// Functie om te werken met input in de vorm van 'laptopno', struct Review als return
func LoadReviewsForLaptop(LaptopNummer int) ([]Review, error) {
	var reacties []Review // variabele die de struct Review uit types.go als inhoud heeft

	err := LoadData(REVIEWFILE, &reacties) // De data van de json wordt in de reacties geladen. LoadData (helpers.go). De 'path' staat bovenaan deze repository file

	beoordeling := make([]Review, 0) //Slice van de struct Review vanaf positie 0

	for _, mening := range reacties { // 'mening' staat voor de values van reacties dus van de []Review
		if mening.LaptopNummer == LaptopNummer { // Wanneer het nummer van de laptop uit reacties ([]Review) gelijk is aan het laptopnummer uit []Laptop
			beoordeling = append(beoordeling, mening) //.. Dan voegt hij 'beoordeling' dus de slice van []Review vanaf positie 0 aan mening (values van reacties ([]Review))
		}
	}
	return beoordeling, err
}

// haalt de gespecificeerde laptopsfile op en laadt deze in een temp file
func LoadLaptops() ([]Laptop, error) {
	var laptops []Laptop
	err := LoadData(LAPTOPSFILE, &laptops)

	return laptops, err
}

// haalt de gespecificeerde reviews op en laadt deze in een temp file
func LoadReviews() ([]Review, error) {
	var beoordelingen []Review
	err := LoadData(REVIEWFILE, &beoordelingen)

	return beoordelingen, err
}

// itereert door de reeds geladen laptops en geef de bestaande laptops terug
func GetLaptop(no int) (Laptop, error) {
	laptops, _ := LoadLaptops()
	for _, laptop := range laptops {
		if laptop.No == no {
			return laptop, nil
		}
	}
	return Laptop{}, errors.New("The Laptop with the given n.o. could not be found")
}
// itereert door de reeds geladen laptops en geef de bestaande laptops terug
func GetReviews(no int) (Review, error) {
	beoordelingen, _ := LoadReviewsForLaptop(no)
	for i, review := range beoordelingen {
		for j, review2 := range beoordelingen{
			if review == review2 && j > i{
				
				return review, nil
			}
		}
			
			
		
	}
	
	return Review{}, errors.New("The Review with the given n.o. could not be found")
}


// idem
func LoadCustomers() ([]Customer, error) {
	var customers []Customer
	err := LoadData(CUSTOMERSFILE, &customers)

	return customers, err
}

// idem
func LoadOrders() ([]Order, error) {
	var orders []Order
	err := LoadData(ORDERSFILE, &orders)

	return orders, err
}

// itereert door de bestaande costumers en geeft overeenkomstige nummers terug of geeft een foutmleding
func SaveCustomer(data Customer) error {
	log.Println("Saving customer: ", data)

	if data.Email == "" {
		return errors.New("The customer is not defined")
	}

	customers, err := LoadCustomers()
	if err != nil {
		return err
	}

	for _, customer := range customers {
		if customer.Email == data.Email {
			return errors.New("The customer already exists")
		}
	}

	customers = append(customers, data)

	return SaveData(CUSTOMERSFILE, customers)
}

// idem
func SaveOrder(data Order) error {
	log.Println("Saving order: ", data)

	if data.No == 0 || data.Email == "" {
		return errors.New("The order is not defined")
	}

	orders, _ := LoadOrders()

	for _, order := range orders {
		if order.No == data.No {
			return errors.New("The order already exists")
		}
	}

	orders = append(orders, data)

	return SaveData(ORDERSFILE, orders)
}

// idem
func SaveReview(data Review) error {
	var reviews []Review
	log.Println("Saving review", data)

	_ = LoadData(REVIEWFILE, &reviews)

	reviews = append(reviews, data)

	err := SaveData(REVIEWFILE, reviews)

	return err
}
