package handlers

import (
	"html/template"
	"log"
	"net/http"
	"strconv"
	// "fmt"
	"../repository"
	"../types"
)

type Laptopdetail struct {
	Review []types.Review
	Laptop types.Laptop
}

func LaptopdetailsHandler(response http.ResponseWriter, request *http.Request) {
	log.Println("Viewing laptop details")

	tmp := request.URL.Query()["no"]
	laptopno, err := strconv.Atoi(tmp[0])

	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "/html/error.html", http.StatusBadRequest)
		return
	}

	laptop, err := repository.GetLaptop(laptopno)
	beoordelingen, err := repository.LoadReviewsForLaptop(laptopno)
	// beoordeling, err:= repository.GetReviews(laptopno)
	
	// if err != nil {
	// 	log.Println(err)
	// 	http.Redirect(response, request, "/html/error.html", http.StatusInternalServerError)
	// 	return
	// }else{
	// 	log.Println(beoordeling)	
	
	// }
	
	// log.Println((len(beoordelingen)))
	// fmt.Println(beoordelingen)
	// fmt.Println(beoordelingen[0])
	// fmt.Println(beoordelingen[1])
	if request.Method == "POST" {
		request.ParseForm()
		customer := types.Customer{
			Email:   request.FormValue("email"),
			Name:    request.FormValue("name"),
			Address: request.FormValue("address"),
			Phone:   request.FormValue("phone"),
		}

	// Save the customer to the JSON file
	repository.SaveCustomer(customer)

	}	
	
					
	render, _ := template.ParseFiles("templates/laptopdetails.html")
	Data:= Laptopdetail{
		Laptop: laptop,
		Review: beoordelingen,
	}
	render.Execute(response, Data)
	return
	

		

	
}
