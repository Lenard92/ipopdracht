package handlers

import (
	"html/template"
	"log"
	"net/http"
	
	// "strconv"
	// "time"

	"../repository"
	. "../types"
)

func PostreviewHandler(response http.ResponseWriter, request *http.Request) {
	log.Println("Posting review")

	
	// tmp := request.URL.Query()["no"]
	// laptopno, err := strconv.Atoi(tmp[0])

	// if err != nil {
	// 	log.Println(err)
	// 	http.Redirect(response, request, "/html/error.html", http.StatusBadRequest)
	// 	return
	// }

	if request.Method == "POST" {

		request.ParseForm()

		review := Review{
			
			Naam:    request.FormValue("naam"),		
			Toelichting:   request.FormValue("toelichting"),
			Auteur: request.FormValue("auteur"),
		}
	
		

		// Save the customer to the JSON file
		// Datum:= time.Now()
		// LaptopNummer := laptopno
		// Score := 

		repository.SaveReview(review)

		log.Printf("Placing review %v", review)

		render, _ := template.ParseFiles("templates/plaatsenreviewsucces.html")
		render.Execute(response, review)	
	}
	
	
}
		
		


		
	

	
