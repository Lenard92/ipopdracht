package types

import "time"

type Order struct {
	No         int         `json:"no"`
	Email      string      `json:"email"`
	Date       time.Time   `json:"date"`
	OrderLines []OrderLine `json:"lines"`
	Total      float32     `json:"total"`
}

type OrderLine struct {
	LaptopNo int `json:"laptopno"`
	Quantity int `json:"quantity"`
}
