package types

import "time"

type Review struct {
	LaptopNummer int    `json:"laptopnummer"`
	Naam         string `json:"naam"`
	Score        int    `json:"score"`
	Toelichting  string `json:"toelichting"`
	Datum       time.Time `json:"datum"`
	Auteur string `json:"auteur"`
}
