package handlers

import (
	"html/template"
	"log"
	"net/http"

	"../repository"
)

// LaptopsHandler parses laptops.json to the laptops.html template and notifies the user when viewing this template.
func LaptopsHandler(response http.ResponseWriter, request *http.Request) {
	log.Println("Viewing laptops")

	laptops, _ := repository.LoadLaptops()

	render, err := template.ParseFiles("templates/laptops.html")

	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "../html/error.html", http.StatusBadRequest)
	}

	render.Execute(response, laptops)
}
