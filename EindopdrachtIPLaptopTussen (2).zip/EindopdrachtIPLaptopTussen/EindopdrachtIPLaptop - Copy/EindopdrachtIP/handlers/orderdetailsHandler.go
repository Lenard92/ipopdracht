package handlers

import (
	"html/template"
	"log"
	"net/http"
	"strconv"

	"../repository"
)

//OrderdetailsHandler parses orders.json to the orderdetails.html template and notifies the user.
func OrderdetailsHandler(response http.ResponseWriter, request *http.Request) {
	log.Println("Viewing order details")

	tmp := request.URL.Query()["no"]
	orderno, err := strconv.Atoi(tmp[0])

	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "/html/error.html", http.StatusBadRequest)
		return
	}

	orders, err := repository.LoadOrders()

	if err != nil {
		log.Println(err)
		http.Redirect(response, request, "/html/error.html", http.StatusInternalServerError)
		return
	}

	for _, order := range orders {
		if order.No == orderno {
			render, _ := template.ParseFiles("templates/orderdetails.html")

			render.Execute(response, order)
			return
		}
	}

	http.Redirect(response, request, "/html/error.html", http.StatusFound)
}
