# ICT-DEV-IP-18 Starter
Programmeeropdracht voor module ICT-DEV-IP-18

<!-- #### Eindopdracht 1. Meer laptops
> Complexiteit: ★☆☆☆☆

Het aanbod van laptops is nog niet zo groot. Voeg 3 nieuwe laptops (met realistische specificaties) toe aan de huidige verzameling. Controleer jouw nieuwe lijst op `http://localhost:8080/laptops`. -->

<!-- #### Eindopdracht 2. Extra specificaties
> Complexiteit: ★★☆☆☆

Op dit moment hebben we bepaalde specificaties per laptop:

- Processortype
- Schermgrootte
- RAM
- GPU
- Opslagruimte (HD)

Jij gaat nu een aantal specificaties toevoegen aan de laptops:

- Aantal cores
- Besturingssysteem
- Gewicht
- Toetsenbordindeling

De huidige lijst aan laptops wordt uitgebreid met deze informatie, en wordt zichtbaar in de lijst van laptops op `http://localhost:8080/laptops`.

Maak eerst een stappenplan: Welke stappen neem jij eerst? Hoe bouw jij jouw code op? Welke plekken van jouw applicatie worden aangepast? -->

<!-- #### Eindopdracht 3. Totaalbedrag order
> Complexiteit: ★★☆☆☆

Momenteel zit er een 'bug' in de website waardoor het totaal van alle orders onjuist is. De functie die hiervoor wordt gebruikt is `calculateTotal` in `handlers/orderlaptopHandler.go`. Pas deze functie aan zodat (i) het totaal van de order juist berekend wordt en (ii) op de website getoond wordt. -->

<!-- #### Eindopdracht 4. Laptop details
> Complexiteit: ★★★★☆

Op dit moment is er een lijst van laptops beschikbaar op `http://localhost:8080/laptops`. Nu gaan we een nieuwe pagina maken voor de laptop details. Deze pagina toont alle informatie (inclusief afbeelding). Vanuit de `/laptops` pagina moet jij per laptop kunnen doorklikken naar deze detail-pagina. De URL hiervoor wordt `/laptopdetails?no=[laptopno]`.

Maak eerst weer een stappenplan: Welke stappen neem jij eerst? Hoe bouw jij jouw code op? Hoe registreer jij een nieuw _endpoint_? -->

<!-- #### Eindopdracht 5. Reviews weergeven
> Complexiteit: ★★★★★

Op de de detailpagina van de laptops moeten reviews worden weergegeven. Reviews bestaan uit de volgende informatie:

- Naam
- Score (0 - 10)
- Toelichting
- Datum van plaatsing
- Auteur (emailadres)

Let op: In deze opdracht gaat het alleen om het weergeven van reviews. Hierbij volg je de volgende stappen:

1. Maak een nieuwe `.json` file aan in de `data` folder genaamd `reviews.json`.
2. Vul deze `reviews.json` met de eerste reviews (minimaal twee reviews van verschillende auteurs per laptop). Kijk hierboven voor de data die je wil opslaan. Daarnaast moet jij het `laptopno` opslaan, zodat jij weet bij welke laptop de review hoort.
3. Maak een nieuw `struct` type in `types/types.go`.
4. Breid `repository/repository.go` uit met de functie `LoadReviewsForLaptop(laptopno int) ([]Review, error) {}`. Deze functie krijgt het `laptopno` binnen, en geeft een array van het type `Review` terug uit `data/reviews.json`.
5. Bewerk `handlers/laptopdetailsHandler.go` zodat alle review-data wordt meegegeven aan de HTML.
6. Bewerk `templates/laptopdetails.html` zodat daar alle reviews van de betreffende laptop getoond worden.  -->

#### Eindopdracht 6. Reviews plaatsen
> Complexiteit: ★★★★★

Boven de getoonde reviews moet nu een formulier komen zodat bezoekers een nieuwe review kunnen plaatsen bij één specifieke laptop. Hierbij volg je de volgende stappen:

1. Breid `repository/repository.go` uit met de functie `SaveReview(data Review) error {}`, en implementeer deze.
2. Maak een [HTML formulier](https://www.w3schools.com/html/html_forms.asp) op je laptopdetails pagina (e.g. `templates/laptopdetails.html`). Het formulier krijgt als `HTTP method` om een `POST` request te doen naar `/postreview`.
3. Maak een nieuwe handler genaamd `postreviewHandler` in `handlers/postreviewHandler.go`. 
4. Het endpoint voor deze handler wordt `/postreview`, deze voeg jij toe in `main.go`.
5. Maak de implementatie van de `postreviewHandler`. Hier haal jij de data van het formulier op, en roep jij de functie `SaveReview` aan.
6. In de handler: na het opslaan wordt de gebruiker [doorgestuurd (redirect)](https://golang.org/pkg/net/http/#Redirect) naar de betreffende laptopdetail pagina, waar de nieuwe review zichtbaar wordt.

#### Eindopdracht 7. Voorbereiding assessment
Ingangseis: Jouw website functioneert volgens de bovenstaande specificaties.

Neem de toetsmatrijs door en bereid jezelf voor op vragen die jij kunt verwachten bij de verschillende leeruitkomsten (jouw toelichtingen zijn een belangrijk onderdeel van jouw eindcijfer). 

Jij hebt een werkende demo en zorgt dat jij klaar zit als jij aan de beurt bent. Dit houdt in dat jouw eigen laptop opgeladen is en dat Visual Studio Code is opgestart met jouw programmacode geladen en gereed voor gebruik. In het eerste deel van de toets geef je een demo van de applicatie aan de hand van een aantal usecases die je moet uitvoeren met jouw demo. Vervolgens doen wij een codereview. In totaal duurt de toets ongeveer 20 minuten.

Tijdens het assessment krijg jij de kans om de assessor te overtuigen van de werkende code én van het feit dat jij die code gemaakt hebt. Let op het principe van plagiaat: Samenwerken aan één probleem, betekent niet dat jij dezelfde oplossing inlevert! Verder is het ontbreken van een toelichting op een gebruikte oplossing reden om een onvoldoende te geven!
