package main

import (
    "net/http"
    "text/template"
)

func main() {
    http.HandleFunc("/", func(w http.ResponseWriter, req *http.Request) {
        w.Header().Add("Content Type", "text/html")
        // The template name "template" does not matter here
        templates := template.New("template")
        // "doc" is the constant that holds the HTML content
        templates.New("doc").Parse(doc)
        context := Context{
            Title: "My Fruits",
            Name: "John",
            Fruits: [3]string{"Apple", "Lemon", "Orange"},
        }
        templates.Lookup("doc").Execute(w, context)
    })
    http.ListenAndServe(":8000", nil)
}

// The const and struct we declared are here