package main

import (
	"log"
	"net/http"

	"./handlers"
)

func main() {

	log.Println("Starting app")

	http.HandleFunc("/laptops", handlers.LaptopsHandler)
	http.HandleFunc("/orders", handlers.OrdersHandler)
	http.HandleFunc("/laptopdetails", handlers.LaptopdetailsHandler)
	http.HandleFunc("/orderdetails", handlers.OrderdetailsHandler)
	http.HandleFunc("/orderlaptop", handlers.OrderlaptopHandler)

	http.Handle("/html/", http.StripPrefix("/html/", http.FileServer(http.Dir("./html"))))
	http.Handle("/images/", http.StripPrefix("/images/", http.FileServer(http.Dir("./images"))))

	log.Fatal(http.ListenAndServe(":8080", nil))
}
